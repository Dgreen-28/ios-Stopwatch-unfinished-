//
//  ViewController.swift
//  A03_Green_Corey
//
//  Created by Decoreyon Green on 3/30/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var laps: [String] = []
    
    var timer = Timer()
    var minutes:  Int = 0
    var seconds: Int = 0
    var fractions: Int = 0
    var lapnum: Int = 0
    
    var cminutes:  Int = 0
    var cseconds: Int = 0
    var cfractions: Int = 0
    
    var stopwatchString: String = ""
    var cstopwatchString: String = ""
    
    var startStopwatch: Bool = true
    var addLap: Bool = false
    
    
    @IBOutlet weak var lapnumLabel: UILabel!
    @IBOutlet weak var lapsTableView: UITableView!
    @IBOutlet weak var TTimeLabel: UILabel!
    @IBOutlet weak var CLapLabel: UILabel!
    @IBOutlet weak var StartStopButton: UIButton!
    @IBOutlet weak var NewLapButton: UIButton!
    @IBOutlet weak var LaunchScreenBackButton: UIImageView!
    @IBOutlet weak var resetButton: UIButton!
    
    @IBAction func StopStart(_ sender: Any) {
        if startStopwatch == true{

          timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: Selector(("updatestopwatch")), userInfo: nil, repeats: true)
            startStopwatch = false

            StartStopButton.setImage(UIImage(named: "button_stop"), for: UIControl.State.normal)
            addLap = true
            print("tapped")

        }
        else
        {
            timer.invalidate()
            startStopwatch = true
            StartStopButton.setImage(UIImage(named: "button_start"), for: UIControl.State.normal)
            addLap = false
            
        }
    }
    @IBAction func NewLap(_ sender: Any) {
        print("tapped")
        if addLap == true
        {
            CLapLabel.text = "00:00.0"

            cfractions = 0
            cseconds = 0
            cminutes = 0
            
            laps.insert(stopwatchString, at: 0)
    //        lapsTableView.reloadData()
            lapnum += 1
            
        }
        else
        {
            addLap = false
        }
    }
    @IBAction func reset(_ sender: Any) {
        print("tapped")
        laps.removeAll(keepingCapacity: false)
  //      lapsTableView.reloadData()
        
        fractions = 0
        seconds = 0
        minutes = 0
        
        cfractions = 0
        cseconds = 0
        cminutes = 0
        
        lapnum = 0
        
        stopwatchString = "00:00:00"
        TTimeLabel.text = "00:00.0"
        CLapLabel.text = "00:00.0"
        lapnumLabel.text = "0"
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        


        // Do any additional setup after loading the view.
    }
    
    
    @objc func updatestopwatch()
    {
        fractions += 10
        cfractions += 10
        if fractions == 100
        {
            seconds += 1
            fractions = 0
            
            cseconds += 1
            cfractions = 0
        }
        if seconds == 60
        {
            minutes += 1
            seconds = 0
            
            cminutes += 1
            cseconds = 0
        }
        let fractionsString = fractions > 9 ? "\(fractions)" : "0\(fractions)"
        let secondsString = seconds > 9 ? "\(seconds)" : "0\(seconds)"
        let minutesString = minutes > 9 ? "\(minutes)" : "0\(minutes)"
        
        let cfractionsString = cfractions > 9 ? "\(cfractions)" : "0\(cfractions)"
        let csecondsString = cseconds > 9 ? "\(cseconds)" : "0\(cseconds)"
        let cminutesString = cminutes > 9 ? "\(cminutes)" : "0\(cminutes)"
        
        
        
        stopwatchString = "\(minutesString):\(secondsString).\(fractionsString)"
        TTimeLabel.text = stopwatchString
        
        cstopwatchString = "\(cminutesString):\(csecondsString).\(cfractionsString)"
        CLapLabel.text = cstopwatchString
        
        var lapnumString = String(lapnum)
        lapnumLabel.text = lapnumString
        
    }
    
   //TableViewMethods
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = UITableViewCell(style: UITableViewCell.CellStyle.value1, reuseIdentifier: "Cell")
        

        cell.textLabel?.text = "Lap \(laps.count - indexPath.row)"
        
        cell.detailTextLabel?.text = laps[indexPath.row]
        return cell
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return laps.count
    }
}
